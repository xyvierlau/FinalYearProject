<?php        
session_start();
date_default_timezone_set("Asia/Singapore");
include_once ('cfg.inc.php');   

if (isset($_SESSION["u_id"])){
        $uid = $_SESSION['u_id'];
        $uname = $_SESSION['u_name'];
        $u_eth_add = $_SESSION['u_ethadd'];
        $u_role = $_SESSION['u_role'];
        if(isset($_POST["brdept"]))
        {
                $brdept = $_POST["brdept"];
                $brst = $_POST["brst"];
                $branchids = mysqli_query($conn, "SELECT dept_id from department WHERE dept_name = '$brdept' AND dept_state = '$brst';");
                $branchid = json_encode($branchids);
                $serv_type = $_POST["servtype"];
                $crehash = $_POST["crehash"];
                $queueNum = $_POST["queueNum"];
                $mysqltime = date ("Y-m-d H:i:s", time()); 
                $insertsql = "INSERT into jqueue(q_id, branch_id, q_creator, user_id, user_name, qserv_type, qserv_status, qcre_hash, qcre_time, q_creator_address, dept_name) VALUES ('$queueNum', (SELECT dept_id from department WHERE dept_name = '$brdept' AND dept_state = '$brst'),'$u_role','$uid', '$uname', '$serv_type', 'Waiting', '$crehash', '$mysqltime', '$u_eth_add', '$brdept')";    
  
                mysqli_query($conn, $insertsql);
                 exit;
        }
       


}
