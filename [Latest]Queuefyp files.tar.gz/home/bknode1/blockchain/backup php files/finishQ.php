<?php
session_start();
date_default_timezone_set("Asia/Singapore");
include_once 'cfg.inc.php';
if(isset($_POST['finqueNum'])){
	$finqueinfo = $_POST['finqueinfos'];
	$servhash = $_POST['servhash'];
	$finqueNum = $_POST['finqueNum'];
	$finbranch = $_POST['finbranch'];
	 $mysqltime = date ("Y-m-d H:i:s", time()); 
	$fininsert = "UPDATE jqueue SET qserv_info='$finqueinfo', qserv_time= '$mysqltime', qserv_hash ='$servhash',qserv_status = 'Completed' where q_id = '$finqueNum' AND branch_id = '$finbranch'";
	$finstatus = "UPDATE jqueue set qserv_status = 'Completed' where q_id = '$finqueNum'";
	mysqli_query($conn, $fininsert);
	mysqli_query($conn, $finstatus);
	exit;
}