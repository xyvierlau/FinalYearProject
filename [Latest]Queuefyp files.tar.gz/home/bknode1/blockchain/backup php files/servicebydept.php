<?php //OUPUT OPTIONS through Ajax for create Queue page
include('cfg.inc.php');
if(isset($_POST['deptst']) && (isset($_POST['deptname']))){
	$deptst = $_POST['deptst'];
	$deptname = $_POST['deptname'];
	$queryservices = "SELECT serv_desc FROM service where serv_branch = (SELECT dept_id from department WHERE dept_name = '$deptname' AND dept_state = '$deptst')";
	$quservices = mysqli_query($conn, $queryservices);
	$result = array();
	echo '<select name="services" id="services" class="form-control" style="font-size: 3vw">';
	echo '<option disabled selected value> -- select an option -- </option>';
while ($row = $quservices->fetch_assoc()){
	echo '<option value="' . $row['serv_desc'] . '">' . $row['serv_desc'] . '</option>';
}
}
?>
