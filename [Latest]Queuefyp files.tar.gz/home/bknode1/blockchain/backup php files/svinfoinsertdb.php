<?php        
session_start();
date_default_timezone_set("Asia/Singapore");
include_once ('cfg.inc.php');   

        if(isset($_POST["finqueinfo"]))
        {
                $svcinfo = $_POST["finqueinfo"];
                $svchash = $_POST["servhash"];
                
                $action = 'FinishQueue';
                $mysqltime = date ("Y-m-d H:i:s", time()); 
                $insertsql = "INSERT into serviceinfo( sv_action, sv_info, sv_hash, sv_time) VALUES ('$action', '$svcinfo', '$svchash', '$mysqltime');";    
                mysqli_query($conn, $insertsql);
                 exit;
        }

         if(isset($_POST["nxqueue"]))
        {
                $action = 'NextQueue';
                $nxhash = $_POST["nxqueue"];
                $mysqltime = date ("Y-m-d H:i:s", time()); 
                $insertsql = "INSERT into serviceinfo (sv_action, sv_hash, sv_time) VALUES('$action', '$nxhash', '$mysqltime');";    
                mysqli_query($conn, $insertsql);
                 exit;
        }
        if(isset($_POST["newdayid"]))
        {
                $action = 'NewDay';
                $ndhash = $_POST["newdayid"];
                $mysqltime = date ("Y-m-d H:i:s", time()); 
                $insertsql = "INSERT into serviceinfo (sv_action, sv_hash, sv_time) VALUES('$action', '$nxhash', '$mysqltime');";    
                mysqli_query($conn, $insertsql);
                 exit;
        }
       

       

