<?php
include 'cfg.inc.php';
if(isset($_POST['u_role'])){
	$role = $_POST['u_role'];
	
	$role_add = mysqli_query($conn, "SELECT role_address from role WHERE user_role = '$role'");
	$row = mysqli_fetch_assoc($role_add);
	echo $row['role_address'];
}