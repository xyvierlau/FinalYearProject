<?php
if(isset($_POST['branchid'])){
	$branchid = $_POST['branchid'];
		include_once 'cfg.inc.php';
		$getAddsyn = "Select contract_address from department where dept_id = '$branchid';";
		$getAdd = mysqli_query($conn, $getAddsyn);
		$returnAdd = mysqli_fetch_assoc($getAdd);
		echo $returnAdd['contract_address'];
}