<?php
session_start();
date_default_timezone_set("Asia/Singapore");
include_once 'cfg.inc.php';
if(isset($_POST['cancelqueue'])){
	$cancelq = $_POST['cancelqueue'];
	$canceltxn =$_POST['canceltxn'];
	$mysqltime = date ("Y-m-d H:i:s", time()); 
	$cancelsyn = "UPDATE jqueue SET qserv_status = 'Cancelled', qcancel_time= '$mysqltime', qcancel_hash = '$canceltxn' WHERE queue='$cancelq'";
	mysqli_query($conn, $cancelsyn);
}