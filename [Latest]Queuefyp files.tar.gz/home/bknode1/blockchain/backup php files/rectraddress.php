<?php
session_start();
include_once ('cfg.inc.php');   
if(isset($_POST)){
	$state = $_POST['state'];
	$deptname = $_POST['deptname'];
	$fctradd = "SELECT contract_address from department where dept_state='$state' AND dept_name = '$deptname'";
	$ContractAddress = mysqli_query($conn,$fctradd);
	$row = mysqli_fetch_assoc($ContractAddress);
	echo $row['contract_address'];
}
?>

