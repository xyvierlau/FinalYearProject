<?php


$db_server ='localhost';
$db_user='bknode1';
$db_pass='admin123';
$db='fyp_queue';

$conn = mysqli_connect($db_server,$db_user,$db_pass,$db) or die("error");

// $host="localhost";
// $port=3306;
// $socket="";
// $user="lau";
// $password="";
// $dbname="fyp_queue";

// $con = new mysqli($host, $user, $password, $dbname, $port, $socket)
// 	or die ('Could not connect to the database server' . mysqli_connect_error());

?>
