<?php
if(isset($_POST['submit'])){

	include_once '../cfg.inc.php';
	$name = mysqli_real_escape_string($conn, $_POST['name']);
	$bdate = mysqli_real_escape_string($conn, $_POST['birthdate']);
	$hpnum = mysqli_real_escape_string($conn, $_POST['hpnum']);
	$state = mysqli_real_escape_string($conn, $_POST['state']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$uid = mysqli_real_escape_string($conn, $_POST['uid']);
	$pwd = mysqli_real_escape_string($conn, $_POST['pwd']);
	date_default_timezone_set("Asia/Singapore");
	$mysqltime = date ("Y-m-d H:i:s", time());
	echo $name;
	echo $hpnum;
	echo "<br>";
	echo $bdate;
	echo "<br>";
	echo $state;
	echo "<br>";
	echo $email;
	echo "<br>";
	echo $uid;
	echo "<br>";
	echo $pwd;
	echo "<br>";
	echo $mysqltime;
	echo "<br>";
	$hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);
	echo "<br>";
	echo $hashedPwd;
					//Inserting user into DB
					$sqlinsert = "INSERT INTO users (user_id, user_name, user_role, user_mail, user_phone, user_password, user_state, user_bday, date_created) VALUES ('$uid','$name','client','$email','$hpnum','$hashedPwd','$state', '$bdate','$mysqltime');";
					mysqli_query($conn, $sqlinsert);
				}