<?php
if(isset($_POST['submit'])){

	include_once '../cfg.inc.php';
	$name = mysqli_real_escape_string($conn, $_POST['name']);
	$bdate = mysqli_real_escape_string($conn, $_POST['birthdate']);
	$hpnum = mysqli_real_escape_string($conn, $_POST['hpnum']);
	$state = mysqli_real_escape_string($conn, $_POST['state']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$uid = mysqli_real_escape_string($conn, $_POST['uid']);
	$pwd = mysqli_real_escape_string($conn, $_POST['pwd']);
	date_default_timezone_set("Asia/Singapore");
	$mysqltime = date ("Y-m-d H:i:s", time());

if(empty($name))
{
	echo "empty name";
}
else{
	echo "name present";
}
	//Error handlers
	if (empty($name)|| empty($bdate)|| empty($hpnum) || empty($email)|| empty($uid)|| empty($pwd) ){
		header("Location: ../loginandregister/register.php?register=empty");
		exit();

	} 
	else{
		//Check characters valid
		if (!preg_match('/^[a-zA-Z\s]+$/', $name)){
			header("Location: ../loginandregister/register.php?register=invalid");
			exit();
		}
		else{
			if (!filter_var($email, FILTER_VALIDATE_EMAIL )){
				header("Location: ../loginandregister/register.php?register=emailerror");
				exit();
			}
			else {
				//query username from db
				$sql = "SELECT * FROM users WHERE user_id='$uid'";
				$result = mysqli_query($conn, $sql);
				$resultCheck = mysqli_num_rows($result);
				if($resultCheck > 0){
					//check user exist
					header("Location: ../loginandregister/register.php?register=userexist");
					exit();
				}
				else{
					//hashing password
					$hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);
					//Inserting user into DB
					$sqlinsert = "INSERT INTO users (user_id, user_name, user_role, user_mail, user_phone, user_password, user_state, user_bday, date_created) VALUES ('$uid','$name','client','$email','$hpnum','$hashedPwd','$state', '$bdate','$mysqltime');";
					mysqli_query($conn, $sqlinsert);
					header("Location: ../loginandregister/login.php?loginnow");
					exit();
				}

			}
		}

	}


}
else{
	header("Location: ../register.php");
	exit();
}
