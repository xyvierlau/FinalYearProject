<?php

session_start();
if(isset($_POST['submit'])){
	include '../cfg.inc.php';

	$Uid = mysqli_real_escape_string($conn,$_POST['uid']);
	$Pwd = mysqli_real_escape_string($conn,$_POST['pwd']);

	
	if(empty($Uid) || empty($Pwd)) {
		 header("Location: ../loginandregister/login.php?login=empty");
		exit();
	}
	else {
		$unsql = "SELECT * FROM users WHERE user_id='$Uid' OR user_mail='$email'";
		$result = mysqli_query($conn, $unsql);
		$resultCheck = mysqli_num_rows($result);
		echo $resultCheck;

		if ($resultCheck < 1){
			header("Location: ../loginandregister/login.php?login=error");
			exit();
		}
		else {
			if($row = mysqli_fetch_assoc($result)){
				//De-hash password
				$hashedPwdCheck = password_verify($Pwd, $row['user_password']);
				if ($hashedPwdCheck == false){
					header("Location: ../loginandregister/login.php?login=pwderror");
					exit();
				}
				elseif ($hashedPwdCheck == true){
					//Log in the user and set _SESSION var
					$_SESSION['u_id'] =  $row['user_id'];
					$_SESSION['u_name'] =  $row['user_name'];
					$_SESSION['u_hpnum'] =  $row['user_phone'];
					$_SESSION['u_email'] =  $row['user_email'];
					$_SESSION['u_ethadd'] = '0xb221717c7e3c95a2ab0c718facfaa8ea27a02b23'; //Guest eth address, also means eth.accounts[1]
					$_SESSION['u_role'] = $row['user_role'];
					if ($_SESSION['u_role'] == 'client')
					{
						header("Location: ../clientwallet.php");
					}
					else if($_SESSION['u_role'] == 'admin')
					{
						header("Location: ../servicedesk.php");
					}

				}
				
			}
		}
	}
}
else{
	echo "error";
	exit();
}